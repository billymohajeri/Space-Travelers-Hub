import React, { useDispatch, useSelector } from 'react-redux';
import { useEffect } from 'react';
import classes from './table.module.css';
import { getMissions } from '../Redux/missions/missions';

const Missions = () => {
  const missions = useSelector((state) => state.missions);
  const dispatch = useDispatch();
  const error = useSelector((state) => state.error);
  useEffect(() => {
    dispatch(getMissions());
  }, [dispatch]);

  return (
    <div>
      {error ? (
        <div className={classes.error}>An error occurred while fetching missions</div>
      ) : (
        <table className={classes.table}>
          <thead>
            <tr>
              <th>Mission</th>
              <th>Description</th>
              <th>Status</th>
              <th> </th>
            </tr>
          </thead>
          <tbody>
            {missions.map((mission) => (
              <tr key={mission.mission_name}>
                <td className={classes.mission_name}>{mission.mission_name}</td>
                <td className={classes.mission_description}>
                  {mission.description}
                </td>
                <td className={classes.mission_status}>
                  {mission.launch_success ? 'Not a member' : 'Active Member'}
                </td>
                <td className={classes.mission_join_leave}>
                  {mission.launch_success ? 'Join Mission' : 'Leave Mission'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default Missions;
