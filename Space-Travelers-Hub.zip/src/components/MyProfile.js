const myProfile = () => <h2>Hello fome My Profile page</h2>;

export default myProfile;
